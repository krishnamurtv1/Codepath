from ingest import load_documents, clean_text

def chunk_text(text, chunk_size=300, overlap=75):
    chunks = []
    start = 0

    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        if chunk.strip():
            chunks.append(chunk.strip())
        start += chunk_size - overlap

    return chunks

def chunk_documents():
    docs = load_documents()
    all_chunks = []

    for doc in docs:
        clean = clean_text(doc["text"])
        chunks = chunk_text(clean)
        for i, c in enumerate(chunks):
            all_chunks.append({
                "source": doc["source"],
                "chunk_id": i,
                "text": c
            })

    return all_chunks

if __name__ == "__main__":
    chunks = chunk_documents()
    print(f"Total chunks: {len(chunks)}\n")

    for c in chunks[:5]:
        print("----")
        print(f"Source: {c['source']}")
        print(c["text"])