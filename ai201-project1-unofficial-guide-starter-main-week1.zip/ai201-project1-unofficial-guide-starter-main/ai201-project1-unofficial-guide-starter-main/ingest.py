from pathlib import Path
import re

def load_documents(data_dir="data"):
    documents = []
    for path in Path(data_dir).glob("*.txt"):
        text = path.read_text(encoding="utf-8")
        documents.append({
            "source": path.name,
            "text": text
        })
    return documents

def clean_text(text):
    text = re.sub(r"<.*?>", "", text)
    text = re.sub(r"&nbsp;|&amp;", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()

if __name__ == "__main__":
    docs = load_documents()
    for d in docs:
        d["text"] = clean_text(d["text"])

    print(f"Loaded {len(docs)} documents\n")
    print("Sample document:\n")
    print(docs[0]["text"][:500])