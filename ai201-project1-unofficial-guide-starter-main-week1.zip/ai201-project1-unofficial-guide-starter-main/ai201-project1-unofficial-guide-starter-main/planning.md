# Project 1 Planning: The Unofficial Guide

> Write this document before you write any pipeline code.
> Your spec and architecture diagram are what you'll use to direct AI tools (Claude, Copilot, etc.) to generate your implementation — the more specific they are, the more useful the generated code will be.
> Update the Retrieval Approach and Chunking Strategy sections if you change your approach during implementation.
> Update this file before starting any stretch features.

---

## Domain

<!-- What domain did you choose? Why is this knowledge valuable and hard to find through official channels? -->

## Domain
This system covers student experiences and reviews of Computer Science professors at my university, including teaching quality, workload, grading fairness, and course difficulty. While this information exists online, it is scattered across review sites, forums, and informal discussions, making it difficult to search or compare professors using traditional tools.

---

## Documents

<!-- List your specific sources: URLs, subreddit names, forum threads, or file descriptions.
     Aim for at least 10 sources that together cover different subtopics or perspectives within your domain. -->

     <!--
     Documents

The document corpus is composed of a mix of short review pages and discussion threads that reflect real student experiences from different perspectives:

RateMyProfessors – CS Professor A
https://www.ratemyprofessors.com/professor/XXXXX
RateMyProfessors – CS Professor B
https://www.ratemyprofessors.com/professor/YYYYY
RateMyProfessors – CS Professor C
https://www.ratemyprofessors.com/professor/ZZZZZ
Reddit thread: “Which CS professors are hardest at MSU?”
https://www.reddit.com/r/montclairstate/comments/AAAAA
Reddit thread: “Best CS professors for internship preparation”
https://www.reddit.com/r/montclairstate/comments/BBBBB
Reddit thread: “Which CS classes have the toughest grading?”
https://www.reddit.com/r/montclairstate/comments/CCCCC
Reddit comment chain discussing exam difficulty in upper-level CS courses
https://www.reddit.com/r/montclairstate/comments/DDDDD
Student blog post describing experiences in MSU CS core courses
(Local file: data/msu_cs_student_blog.txt)
Discord FAQ export from MSU CS student server (anonymized)
(Local file: data/msu_cs_discord_faq.txt)
Department discussion post summarizing course workload expectations
(Local file: data/msu_cs_course_workload.txt)

These sources collectively cover teaching quality, grading strictness, workload, exam structure, and student advice.
     
     -->

| # | Source | Description | URL or location |
|---|--------|-------------|-----------------|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |
| 6 | | | |
| 7 | | | |
| 8 | | | |
| 9 | | | |
| 10 | | | |

---

## Chunking Strategy

<!-- How will you split documents into chunks?
     State your chunk size (in tokens or characters), overlap size, and explain why those
     numbers fit the structure of your documents.
     A review-heavy corpus warrants different chunking than a long FAQ. 
     
     Most documents in this corpus consist of short, opinion-based reviews ranging from one to three sentences, particularly on Rate My Professors. Reddit threads contain slightly longer comments, but key insights are often concentrated within a single paragraph or reply. Based on this structure, documents will be split into 250-character chunks with a 50-character overlap.

This chunk size is small enough to preserve individual opinions without mixing unrelated reviews, while still being large enough to capture complete thoughts about grading, exams, or teaching style. The 50-character overlap helps ensure that important details that span sentence boundaries are not lost across chunks. If chunks were too small, retrieval would return fragmented or context-poor results; if too large, unrelated opinions could be retrieved together, reducing relevance.-->

**Chunk size:** 500 tokens

**Overlap:** 100 tokens

**Reasoning:** A 500-token chunk provides enough context for individual document sections while keeping embeddings focused. A 100-token overlap preserves continuity across chunk boundaries and helps avoid splitting key information across two chunks.

---

## Retrieval Approach

<!-- Which embedding model are you using (e.g., all-MiniLM-L6-v2 via sentence-transformers)?
     How many chunks will you retrieve per query (top-k)?
     If you were deploying this for real users and cost wasn't a constraint, what tradeoffs
     would you weigh in choosing a different embedding model — context length, multilingual
     support, accuracy on domain-specific text, latency?
     
     The system uses the all-MiniLM-L6-v2 embedding model via the sentence-transformers library due to its strong performance on short, semantic text and low latency. For each query, the retriever returns the top 5 most relevant chunks (top-k = 5).

Retrieving too few chunks risks missing relevant perspectives or partial answers, while retrieving too many increases noise and dilutes the context passed to the LLM. Semantic search enables retrieval even when the user’s question does not share exact keywords with the document text, as the embedding model captures meaning rather than surface-level word overlap. If cost were not a constraint, a larger embedding model with longer context support could improve accuracy for nuanced or multi-part questions, but at the cost of latency. -->

**Embedding model:** all-MiniLM-L6-v2 via sentence-transformers

**Top-k:** 5

**Production tradeoff reflection:** In production, a stronger embedding model with more capacity or domain fine-tuning would improve retrieval accuracy at higher cost. For this prototype, all-MiniLM-L6-v2 balances speed and quality for general English text.

---

## Evaluation Plan

<!-- List your 5 test questions with their expected correct answers.
     Questions should be specific enough that you can judge whether the system's response
     is right or wrong. "What are good dining halls?" is too vague.
     "What do students say about wait times at [dining hall name] during lunch?" is testable. -->

| # | Question | Expected answer |
|---|----------|-----------------|
| 1 | What embedding model does the system use for document vectors? | all-MiniLM-L6-v2 |
| 2 | Which vector database stores the embeddings? | ChromaDB |
| 3 | What overlap size is used during chunking? | 100 tokens |
| 4 | How many top chunks are retrieved for each query? | 5 |
| 5 | What stage follows retrieval in the pipeline? | Generation |

---

## Anticipated Challenges

<!-- What could go wrong? Name at least two specific risks with reasoning.
     Consider: noisy or inconsistent documents, missing source attribution, off-topic
     retrieval, chunks that split key information across boundaries. -->

1.      One anticipated challenge is noisy or inconsistent reviews, as student opinions may conflict or vary widely based on individual experience. 

2.   Another risk is chunk boundary issues, where important context (such as a comparison between professors) may be split across adjacent chunks, potentially reducing retrieval quality if overlap is insufficient.

---

## Architecture

```mermaid
flowchart LR
    A[Document Ingestion]\n    B[Chunking]\n    C[Embedding + Vector Store]\n    D[Retrieval]\n    E[Generation]

    A --> B
    B --> C
    C --> D
    D --> E

    subgraph ingestion [ ]
        A ---|"Raw docs from files/URLs"| A
    end
    subgraph chunking [ ]
        B ---|"Text split into ~500-token chunks with 100-token overlap"| B
    end
    subgraph embedding [ ]
        C ---|"all-MiniLM-L6-v2 embeddings"| C
        C ---|"ChromaDB vector store"| C
    end
    subgraph retrieval [ ]
        D ---|"Top-k retrieval from Chroma"| D
    end
    subgraph generation [ ]
        E ---|"LLM answer generation with retrieved chunks"| E
    end
```

---

## AI Tool Plan

<!-- For each part of the pipeline below, describe:
     - Which AI tool you plan to use (Claude, Copilot, ChatGPT, etc.)
     - What you'll give it as input (which sections of this planning.md, which requirements)
     - What you expect it to produce
     - How you'll verify the output matches your spec

     "I'll use AI to help me code" is not a plan.
     "I'll give Claude my Chunking Strategy section and ask it to implement chunk_text()
     with my specified chunk size and overlap" is a plan. 
     
     AI tools will be used selectively to assist with implementing specific pipeline components, based strictly on the design decisions documented in this planning file. AI will not be used to make architectural decisions, only to translate clearly defined specifications into code.

Document Ingestion
AI Tool: ChatGPT
Input Provided:
The Documents section of this planning.md
Instructions that documents are plain text files and online pages already collected
Expected Output:
A Python function to load text documents from local files into memory with associated metadata (source name or URL).
Verification:
I will manually check that each loaded document retains correct source metadata and that no content is modified or summarized during ingestion.
Chunking
AI Tool: ChatGPT
Input Provided:
The Chunking Strategy section of this planning.md
Explicit requirements: 250-character chunks with 50-character overlap
Expected Output:
A chunk_text() function that splits input documents into fixed-size character chunks with overlap and preserves source identifiers.
Verification:
I will test the function on a sample document and confirm chunk length, overlap size, and that adjacent chunks share the correct overlapping characters.
Embedding and Vector Storage
AI Tool: GitHub Copilot
Input Provided:
Inline comments specifying the embedding model (all-MiniLM-L6-v2)
Requirement to use sentence-transformers and store embeddings in ChromaDB
Expected Output:
Code that embeds text chunks using the specified model and stores them in a ChromaDB collection with metadata.
Verification:
I will confirm that embeddings are generated for every chunk and that metadata (source, chunk index) is retrievable from ChromaDB.
Retrieval
AI Tool: ChatGPT
Input Provided:
The Retrieval Approach section of this planning.md
Explicit requirement to retrieve top-k = 5 chunks per query
Expected Output:
A retrieval function that performs semantic search over ChromaDB and returns the top 5 most relevant chunks with metadata.
Verification:
I will issue test queries and verify that retrieved chunks are semantically relevant and consistently limited to five results.
Generation (Grounded Answering)
AI Tool: ChatGPT
Input Provided:
Grounding requirements from Milestone 5
Instruction to answer only using retrieved chunks and to say “I don’t have enough information” if the answer is not supported
Expected Output:
A prompt template and generation function that passes retrieved context to the LLM and enforces grounded responses.
Verification:
I will test questions both covered and not covered by the documents and ensure the system refuses to answer when context is missing.
Interface
AI Tool: ChatGPT
Input Provided:
Gradio UI skeleton from the instructions
Expected response format: answer text + list of sources
Expected Output:
A minimal Gradio interface that accepts a user query and displays the generated answer and its sources.
Verification:
I will run the app locally and confirm that a user can submit a query and clearly see both the answer and its cited sources.
Overall Validation

For each AI-generated component, I will:

Read the generated code before running it
Compare it directly against the specifications in this planning.md
Reject or revise any output that introduces unstated assumptions or deviates from the defined pipeline-->

**Milestone 3 — Ingestion and chunking:**

**Milestone 4 — Embedding and retrieval:**

**Milestone 5 — Generation and interface:**
